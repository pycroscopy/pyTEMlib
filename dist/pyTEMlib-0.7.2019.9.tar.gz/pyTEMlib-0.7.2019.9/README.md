# pyTEMlib

pyTEMlib is a package to read and process various kind of data acquired with a (scanning) transmission electron microscope.

The package is written in pure python and depends on various other libraries.

All data, user input, and results are stored as [pyUSID-type](https://github.com/pycroscopy/pyUSID) files.

I have uploadeda version to pypi which you can install with:

 python3 -m pip install  pyTEMlib
