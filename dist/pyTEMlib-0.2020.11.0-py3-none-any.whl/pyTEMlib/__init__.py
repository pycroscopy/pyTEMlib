# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 10:07:35 2019

@author: gduscher
"""
from .version import _version as __version__

__all__ = ['__version__']

name = "pyTEMlib"
